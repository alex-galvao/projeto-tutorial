package com.example.teste1.Fragments;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.teste1.ConnectionClass;
import com.example.teste1.MainActivity;
import com.example.teste1.PegarDatas;
import com.example.teste1.R;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentReceber extends Fragment {

    private EditText etDataInicio;
    private EditText etDataFim;
    private MainActivity mainActivity;

    private Button btnPesquisarReceber;

    private TextView tvResultado;
    private TextView tvTotal;
    private TextView resultadoTV;
    private TextView totalTV;

    private ListView lvReceber;
    private SimpleAdapter AD;
    private PegarDatas pegarDatas;

    private String i = null;
    private String f = null;

    private Connection connect;
    private String ConnectionResult = "";
    private Boolean isSuccess = false;
    private int resultado = 0;
    private int totalValor;


    public FragmentReceber() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mainActivity = (MainActivity) getActivity();

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_fragment_receber, container, false);

        etDataInicio = rootView.findViewById(R.id.etDtatInicioReceber);
        etDataFim = rootView.findViewById(R.id.etDataFimReceber);
        etDataInicio.setInputType(InputType.TYPE_NULL);
        etDataFim.setInputType(InputType.TYPE_NULL);
        btnPesquisarReceber = rootView.findViewById(R.id.btnPesquisarReceber);
        lvReceber = rootView.findViewById(R.id.LV_Pagar);
        tvResultado = rootView.findViewById(R.id.tvResultadosReceber);
        tvTotal = rootView.findViewById(R.id.tvTotalReceber);
        resultadoTV = rootView.findViewById(R.id.resultadoTV);
        totalTV = rootView.findViewById(R.id.totalTV);
        pegarDatas = new PegarDatas();

        etDataInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pegarDatas.pegarDataInicio(mainActivity, etDataInicio);
            }
        });

        etDataFim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pegarDatas.pegarDataFim(mainActivity, etDataFim);
            }
        });


        btnPesquisarReceber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                List<Map<String, String>> data;
                data = new ArrayList<>();
                resultado = 0;
                i = pegarDatas.setarDataInicio(mainActivity);
                f = pegarDatas.setarDataFim(mainActivity);

                try {

                    ConnectionClass connectionClass = new ConnectionClass();
                    connect = connectionClass.CONN();
                    if (connect == null) {

                        ConnectionResult = "Cheque seu acesso à internet";

                    } else {

                        String query = "SELECT Descricao, Emissao, Valor FROM CReceber WHERE (Emissao >= '" + i + "' and Vencimento <= '" + f + "')";
                        Statement stmt = connect.createStatement();
                        ResultSet rs = stmt.executeQuery(query);

                        String queryTotal = "SELECT SUM(Valor) FROM CReceber WHERE (Emissao >= '" + i + "' and Vencimento <= '" + f + "')";
                        Statement stmtT = connect.createStatement();
                        ResultSet rsT = stmtT.executeQuery(queryTotal);

                        while (rs.next()) {

                            ++resultado;

                            Map<String, String> dataNum = new HashMap<>();
                            dataNum.put("tvPedido", rs.getString("Descricao"));
                            dataNum.put("tvEmissao", String.valueOf(rs.getString("Emissao")));
                            dataNum.put("tvValorReceber", String.valueOf(rs.getString("Valor")));


                            data.add(dataNum);

                            String[] fromWhere = {"tvPedido", "tvEmissao", "tvValorReceber"};
                            int[] viewWhere = {R.id.tvPedido, R.id.tvEmissao, R.id.tvValorReceber};

                            AD = new SimpleAdapter(mainActivity, data, R.layout.list_receber, fromWhere, viewWhere);
                            lvReceber.setAdapter(AD);


                        }

                        while (rsT.next()) {

                            totalValor = rsT.getInt(1);
                            totalTV.setVisibility(View.VISIBLE);
                            tvTotal.setVisibility(View.VISIBLE);
                            tvTotal.setText("R$ " + totalValor);
                        }

                        tvResultado.setText(String.valueOf(resultado));
                        resultadoTV.setVisibility(View.VISIBLE);
                        tvResultado.setVisibility(View.VISIBLE);

                        ConnectionResult = "Successful";
                        isSuccess = true;
                        connect.close();

                    }

                } catch (Exception ex) {

                    isSuccess = false;
                    ConnectionResult = ex.getMessage();

                }

            }
        });

        return rootView;
    }

}
