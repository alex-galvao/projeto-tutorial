package com.example.teste1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import com.example.teste1.Fragments.FragmentEstoque;
import com.example.teste1.Fragments.FragmentFinancas;
import com.example.teste1.Fragments.FragmentHome;
import com.example.teste1.Fragments.FragmentReceber;
import com.example.teste1.Fragments.FragmentVendas;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.sql.Connection;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    Toolbar toolbar;
    BottomNavigationView bnvMain;
    Fragment selectedFragment = null;
    private Connection connect;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bnvMain = findViewById(R.id.bottom_navigation);
        bnvMain.setOnNavigationItemSelectedListener(navListener);
        toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("Hayashi Dashboard");
        toolbar.inflateMenu(R.menu.toolbar);

        toolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.itemSair:
                        Intent sairIntent = new Intent(MainActivity.this, LoginActivity.class);
                        startActivity(sairIntent);
                        finish();
                        return true;

                    case R.id.itemConfig:

                        return true;

                    default:
                        return false;
                }
            }
        });


        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new FragmentHome()).commit();


    }


    private BottomNavigationView.OnNavigationItemSelectedListener navListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {


            switch (item.getItemId()) {

                case R.id.itemHome:
                    selectedFragment = new FragmentHome();
                    break;

                case R.id.itemFinanças:
                    selectedFragment = new FragmentFinancas();
                    break;

                case R.id.itemVendas:
                    selectedFragment = new FragmentVendas();
                    break;

                case R.id.itemEstoque:
                    selectedFragment = new FragmentEstoque();
                    break;

            }

            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, selectedFragment).commit();

            return true;
        }
    };
}
