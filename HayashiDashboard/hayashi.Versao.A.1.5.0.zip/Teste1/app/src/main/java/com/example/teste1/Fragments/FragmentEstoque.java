package com.example.teste1.Fragments;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.QuickContactBadge;
import android.widget.SimpleAdapter;
import android.widget.Spinner;

import com.example.teste1.ConnectionClass;
import com.example.teste1.MainActivity;
import com.example.teste1.R;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentEstoque extends Fragment {

    private Button btnPesquisar;

    private ListView lvEstoque;
    private SimpleAdapter AD;
    private Spinner spnProdutos;

    private Connection connect;
    private String ConnectionResult = "";
    private Boolean isSuccess = false;
    ArrayAdapter<String> arrayAdapter;
    MainActivity mainActivity;


    public FragmentEstoque() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mainActivity = (MainActivity) getActivity();

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_fragment_estoque, container, false);

        ArrayList<String> produtos;
        lvEstoque = rootView.findViewById(R.id.LV_Estoque);
        spnProdutos = rootView.findViewById(R.id.spnProdutos);
        btnPesquisar = rootView.findViewById(R.id.btnPesquisarEstoque);
        mainActivity = new MainActivity();
        produtos = new ArrayList<>();
        produtos.add("TODOS");

        try {

            ConnectionClass connectionClass = new ConnectionClass();
            connect = connectionClass.CONN();
            if (connect == null) {

                ConnectionResult = "Cheque seu acesso à internet";

            } else {

                String queryProduto = "SELECT Descricao FROM GrupoNivel";
                Statement stmtP = connect.createStatement();
                ResultSet rsP = stmtP.executeQuery(queryProduto);

                while (rsP.next()) {


                    produtos.add(rsP.getString("Descricao"));

                    ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(),
                            android.R.layout.simple_spinner_item, produtos);
                    adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
                    spnProdutos.setAdapter(adapter);

                }


                ConnectionResult = "Successful";
                isSuccess = true;
                connect.close();

            }

        } catch (Exception ex) {

            isSuccess = false;
            ConnectionResult = ex.getMessage();

        }

        btnPesquisar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                List<Map<String, String>> data;
                data = new ArrayList<>();
                String produtoSelecionado = spnProdutos.getSelectedItem().toString();
                String grupoProduto = " WHERE GrupoNivel.Descricao = '" + produtoSelecionado + "'";
                if (produtoSelecionado.equals("TODOS")){
                    grupoProduto = "";
                }

                try {

                    ConnectionClass connectionClass = new ConnectionClass();
                    connect = connectionClass.CONN();
                    if (connect == null) {

                        ConnectionResult = "Cheque seu acesso à internet";

                    } else {
                        String queryEstoque = "SELECT" +
                                " Produto_Servico.ID, Produto_Servico.Descricao, EstoqueAtual, EstoqueIdeal, EstoqueMinimo" +
                                " FROM" +
                                " Produto_Estoque" +
                                " INNER JOIN" +
                                " GrupoNivel" +
                                " ON" +
                                " GrupoNivel.ID = Produto_Estoque.ID_Produto" +
                                " INNER JOIN Produto_Servico" +
                                " ON" +
                                " Produto_Servico.ID_Grupo = GrupoNivel.ID" + grupoProduto;

                        Statement stmtE = connect.createStatement();
                        ResultSet rsE = stmtE.executeQuery(queryEstoque);

                        while (rsE.next()) {

                            Map<String, String> dataNum = new HashMap<>();
                            dataNum.put("tvDescricaoEstoque", rsE.getString("Descricao"));
                            dataNum.put("tvCodEstoque", String.valueOf(rsE.getString("ID")));
                            dataNum.put("tvEstoqueMinimo", String.valueOf(rsE.getString("EstoqueMinimo")));
                            dataNum.put("tvEstoqueAtual", String.valueOf(rsE.getString("EstoqueAtual")));
                            dataNum.put("tvEstoqueIdeal", String.valueOf(rsE.getString("EstoqueIdeal")));

                            data.add(dataNum);

                            String[] fromWhere = {"tvDescricaoEstoque", "tvCodEstoque", "tvEstoqueMinimo", "tvEstoqueAtual", "tvEstoqueIdeal"};
                            int[] viewWhere = {R.id.tvDescricaoEstoque, R.id.tvCodEstoque, R.id.tvEstoqueMinimo, R.id.tvEstoqueAtual, R.id.tvEstoqueIdeal};

                            AD = new SimpleAdapter(getActivity(), data, R.layout.list_estoque, fromWhere, viewWhere);
                            lvEstoque.setAdapter(AD);

                        }

                    }

                } catch (Exception ex) {

                    isSuccess = false;
                    ConnectionResult = ex.getMessage();

                }

            }
        });


        return rootView;
    }

}
