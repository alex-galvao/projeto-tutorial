package com.example.teste1.Fragments;


import android.app.DatePickerDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.example.teste1.ConnectionClass;
import com.example.teste1.MainActivity;
import com.example.teste1.PegarDatas;
import com.example.teste1.R;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentVendas extends Fragment {


    private PegarDatas pegarDatas;
    private EditText etDataInicio;
    private EditText etDataFim;
    private MainActivity mainActivity;
    private String i = null;
    private String f = null;
    private Button btnPesquisarVendas;

    private TextView tvResultadoVendas;
    private TextView tvTotalVendas;
    private TextView tvPDVVendas;
    private TextView tvNFEVendas;
    private CardView cdvDados;

    private HorizontalScrollView horizontalScrollView;

    private ListView lvVendas;
    private SimpleAdapter AD;

    private Connection connect;
    private String ConnectionResult = "";
    private Boolean isSuccess = false;

    private int resultado = 0;
    private int totalVendas;
    private int totalNFE;
    private int totalPDV;


    public FragmentVendas() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        mainActivity = (MainActivity) getActivity();

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_fragment_vendas, container, false);

        lvVendas = rootView.findViewById(R.id.LV_Vendas);

        tvResultadoVendas = rootView.findViewById(R.id.tvResultadosVendas);
        tvTotalVendas = rootView.findViewById(R.id.tvTotalVendas);
        tvNFEVendas = rootView.findViewById(R.id.tvNFE);
        tvPDVVendas = rootView.findViewById(R.id.tvPDV);
        cdvDados = rootView.findViewById(R.id.cdvDados);

        horizontalScrollView = rootView.findViewById(R.id.hsvID);

        btnPesquisarVendas = rootView.findViewById(R.id.btnPesquisarVendas);

        btnPesquisarVendas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                List<Map<String,String>> data;
                data = new ArrayList<>();
                i = pegarDatas.setarDataInicio(mainActivity);
                f = pegarDatas.setarDataFim(mainActivity);
                cdvDados.setVisibility(View.VISIBLE);

                try {

                    ConnectionClass connectionClass = new ConnectionClass();
                    connect = connectionClass.CONN();
                    if (connect == null) {

                        ConnectionResult = "Cheque seu acesso à internet";

                    }else {

                        String query="SELECT NaturezaOperacao, DataEmissao, ValorTotal FROM NotaFiscal WHERE (DataEmissao >= '" + i +"' and DataSaida <= '" + f +"') AND (NaturezaOperacao != 'DEVOLUÇÃO DE MERCADORIA')";
                        Statement stmt = connect.createStatement();
                        ResultSet rs = stmt.executeQuery(query);

                        while (rs.next()){

                            ++resultado;

                            Map<String, String> dataNum = new HashMap<>();
                            dataNum.put("tvNatureza",rs.getString("NaturezaOperacao"));
                            dataNum.put("tvEmissaoVenda",String.valueOf(rs.getString("DataEmissao")));
                            dataNum.put("tvValorVenda",String.valueOf(rs.getString("ValorTotal")));


                            data.add(dataNum);

                            String[] fromWhere = {"tvNatureza", "tvEmissaoVenda", "tvValorVenda"};


                            int[] viewWhere = {R.id.tvNatureza, R.id.tvEmissaoVenda, R.id.tvValorVenda};

                            AD = new SimpleAdapter(mainActivity, data, R.layout.list_vendas, fromWhere, viewWhere);
                            lvVendas.setAdapter(AD);


                        }

                        String queryTotal="SELECT SUM(ValorTotal) FROM NotaFiscal WHERE (DataEmissao >= '" + i + "' and DataSaida <= '" + f + "')";
                        Statement stmtT = connect.createStatement();
                        ResultSet rsT = stmtT.executeQuery(queryTotal);

                        while (rsT.next()) {

                            totalVendas = rsT.getInt(1);
                            tvTotalVendas.setVisibility(View.VISIBLE);
                            tvTotalVendas.setText("R$ " + totalVendas);
                        }

                        String queryNFE="SELECT SUM(ValorTotal) FROM NotaFiscal WHERE (DataEmissao >= '" + i + "' and DataSaida <= '" + f + "' and NaturezaOperacao = 'VENDA DE MERCADORIA')";
                        Statement stmtN = connect.createStatement();
                        ResultSet rsN = stmtN.executeQuery(queryNFE);

                        while (rsN.next()) {

                            totalNFE = rsN.getInt(1);
                            tvNFEVendas.setVisibility(View.VISIBLE);
                            tvNFEVendas.setText("R$ " + totalNFE);
                        }

                        String queryPDV="SELECT SUM(ValorTotal) FROM NotaFiscal WHERE (DataEmissao >= '" + i + "' and DataSaida <= '" + f + "' and NaturezaOperacao = 'VENDA CONSUMIDOR')";
                        Statement stmtP = connect.createStatement();
                        ResultSet rsP = stmtP.executeQuery(queryPDV);

                        while (rsP.next()) {

                            totalPDV = rsP.getInt(1);
                            tvPDVVendas.setVisibility(View.VISIBLE);
                            tvPDVVendas.setText("R$ " + totalPDV);
                        }

                        tvResultadoVendas.setText(String.valueOf(resultado));
                        tvResultadoVendas.setVisibility(View.VISIBLE);
                        horizontalScrollView.setVisibility(View.VISIBLE);

                        ConnectionResult = "Successful";
                        isSuccess = true;
                        connect.close();

                    }

                }catch (Exception ex){

                    isSuccess = false;
                    ConnectionResult = ex.getMessage();

                }

            }
        });


        etDataInicio = rootView.findViewById(R.id.etDataInicioVendas);
        etDataFim = rootView.findViewById(R.id.etDataFimVendas);
        etDataInicio.setInputType(InputType.TYPE_NULL);
        etDataFim.setInputType(InputType.TYPE_NULL);
        pegarDatas = new PegarDatas();

        etDataInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pegarDatas.pegarDataInicio(mainActivity, etDataInicio);
            }
        });

        etDataFim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pegarDatas.pegarDataFim(mainActivity, etDataFim);
            }
        });


        return  rootView;
    }

}
