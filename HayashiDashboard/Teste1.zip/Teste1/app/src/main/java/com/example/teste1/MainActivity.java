package com.example.teste1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    Button btnGetData;
    ListView lvData;
    SimpleAdapter AD;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnGetData = findViewById(R.id.btnGet);
        lvData = findViewById(R.id.LV_Data);

        btnGetData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                List<Map<String, String>> MyData = null;
                GetData mData = new GetData();
                MyData = mData.getData();

                String[] fromWhere = {"ID_Produto", "ID_Venda", "Qtd"};

                int[] viewWhere = {R.id.ID_Produto, R.id.ID_Venda, R.id.Qtd};

                AD = new SimpleAdapter(MainActivity.this, MyData, R.layout.listtemplate, fromWhere, viewWhere);
                lvData.setAdapter(AD);


            }
        });


    }
}
